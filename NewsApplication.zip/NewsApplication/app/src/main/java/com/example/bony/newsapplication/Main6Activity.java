package com.example.bony.newsapplication;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

import static java.lang.Math.abs;

public class Main6Activity extends AppCompatActivity {
    TextView textView,textView1,textView2,textView3;
    VideoView image;
    Button btn;
    JSONArray jsonArray;
    JSONObject jsonObj;
    int i=0;
    float x1, y1;
    float x2, y2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);
        StringBuffer buffer = new StringBuffer();
        textView = (TextView) findViewById(R.id.textView1);
        textView1 = (TextView) findViewById(R.id.textView2);
        textView2 = (TextView) findViewById(R.id.textView3);
        textView3 = (TextView) findViewById(R.id.textView4);
        image = (VideoView) findViewById(R.id.videoview);
        btn=(Button) findViewById(R.id.button);

        InputStream is = this.getResources().openRawResource(R.raw.bony);
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        String data = "";
        if (is != null) {
            try {
                while ((data = reader.readLine()) != null) {
                    buffer.append(data + "\n");
                }
                //textView.setText(buffer);
                is.close();
            } catch (Exception e) {
                Toast.makeText(getApplicationContext(), "File not found", Toast.LENGTH_SHORT).show();
            }
        }
        try {
            jsonObj = new JSONObject(buffer.toString());
            jsonArray = jsonObj.getJSONArray("news");
            JSONObject emp = jsonArray.getJSONObject(5);

            String title = emp.getString("title");

            String details = emp.getString("details");
            String flag = emp.getString("image");
            String provider = emp.getString("provider_name");
            String date = emp.getString("created_at");
            String writer = emp.getString("author_name");
            String str = provider + "/" + date;
            textView.setText(title);
            textView1.setText(details);
            textView2.setText(str);
            textView3.setText(writer);
            Uri uri = Uri.parse(flag);
            image.setVideoURI(uri);
            image.start();
            btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(btn.getText().equals("play"))
                    {
                        image.start();
                        btn.setText("Pause");
                    }
                    else
                    {
                        image.pause();
                        btn.setText("play");
                    }
                }
            });



        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public boolean onTouchEvent(MotionEvent touchevent)
    {
        switch (touchevent.getAction())
        {
// when user first touches the screen we get x and y coordinate
            case MotionEvent.ACTION_DOWN:
            {
                x1 = touchevent.getX();
                y1 = touchevent.getY();
                break;
            }
            case MotionEvent.ACTION_UP: {
                x2 = touchevent.getX();
                y2 = touchevent.getY();
            }
//if left to right sweep event on screen

            if (y1 < y2&&(abs(y1-y2)>=100&&(abs(x1-x2)<=100)))
            {
                Intent i = new Intent(Main6Activity.this,Main7Activity.class);
                startActivity(i);
// Toast.makeText(this, "UP to Down Swap Performed", Toast.LENGTH_LONG).show();
            }
//if Down to UP sweep event on screen
            if (y1 > y2&&(abs(y1-y2)>=100&&(abs(x1-x2)<=100)))
            {
                Intent i = new Intent(Main6Activity.this,Main5Activity.class);
                startActivity(i);
// Toast.makeText(this, "Down to UP Swap Performed", Toast.LENGTH_LONG).show();
            }
            break;

        }
        return false;
    }



}
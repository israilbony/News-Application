package com.example.bony.newsapplication;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;

import static java.lang.Math.abs;

public class Main5Activity extends AppCompatActivity {
    TextView textView,textView1,textView2,textView3;
    ImageView image;

    JSONArray jsonArray;
    JSONObject jsonObj;
    int i=0;
    float x1, y1;
    float x2, y2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        StringBuffer buffer = new StringBuffer();
        textView = (TextView) findViewById(R.id.textView1);
        textView1 = (TextView) findViewById(R.id.textView2);
        textView2 = (TextView) findViewById(R.id.textView3);
        textView3 = (TextView) findViewById(R.id.textView4);
        image = (ImageView) findViewById(R.id.imageView1);

        InputStream is = this.getResources().openRawResource(R.raw.bony);
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        String data = "";
        if (is != null) {
            try {
                while ((data = reader.readLine()) != null) {
                    buffer.append(data + "\n");
                }
                //textView.setText(buffer);
                is.close();
            } catch (Exception e) {
                Toast.makeText(getApplicationContext(), "File not found", Toast.LENGTH_SHORT).show();
            }
        }
        try {
            jsonObj = new JSONObject(buffer.toString());
            jsonArray = jsonObj.getJSONArray("news");
            JSONObject emp = jsonArray.getJSONObject(4);

            String title = emp.getString("title");

            String details = emp.getString("details");
            String flag = emp.getString("image");
            String provider = emp.getString("provider_name");
            String date = emp.getString("created_at");
            String writer = emp.getString("author_name");
            String str = provider + "/" + date;
            textView.setText(title);
            textView1.setText(details);
            textView2.setText(str);
            textView3.setText(writer);

            new Main5Activity.DownLoadImageTask(image).execute(flag);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    class DownLoadImageTask extends AsyncTask<String,Void,Bitmap> {
        ImageView imageView;

        public DownLoadImageTask(ImageView imageView){
            this.imageView = imageView;
        }

        /*
            doInBackground(Params... params)
                Override this method to perform a computation on a background thread.
         */
        protected Bitmap doInBackground(String...urls){
            String urlOfImage = urls[0];
            Bitmap logo = null;
            try{
                InputStream is = new URL(urlOfImage).openStream();
                /*
                    decodeStream(InputStream is)
                        Decode an input stream into a bitmap.
                 */
                logo = BitmapFactory.decodeStream(is);
            }catch(Exception e){ // Catch the download exception
                e.printStackTrace();
            }
            return logo;
        }

        /*
            onPostExecute(Result result)
                Runs on the UI thread after doInBackground(Params...).
         */
        protected void onPostExecute(Bitmap result){
            imageView.setImageBitmap(result);
        }
    }

    public boolean onTouchEvent(MotionEvent touchevent)
    {
        switch (touchevent.getAction())
        {
// when user first touches the screen we get x and y coordinate
            case MotionEvent.ACTION_DOWN:
            {
                x1 = touchevent.getX();
                y1 = touchevent.getY();
                break;
            }
            case MotionEvent.ACTION_UP: {
                x2 = touchevent.getX();
                y2 = touchevent.getY();
            }
//if left to right sweep event on screen

// if UP to Down sweep event on screen
                if (y1 < y2&&(abs(y1-y2)>=100&&(abs(x1-x2)<=100)))
                {
                    Intent i = new Intent(Main5Activity.this,Main6Activity.class);
                    startActivity(i);
// Toast.makeText(this, "UP to Down Swap Performed", Toast.LENGTH_LONG).show();
                }
//if Down to UP sweep event on screen
                if (y1 > y2&&(abs(y1-y2)>=100&&(abs(x1-x2)<=100)))
                {
                    Intent i = new Intent(Main5Activity.this,Main4Activity.class);
                    startActivity(i);
// Toast.makeText(this, "Down to UP Swap Performed", Toast.LENGTH_LONG).show();
                }
                break;
            }

        return false;
    }



}